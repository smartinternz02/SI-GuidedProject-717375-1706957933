<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TS_OrangeHRM_002_Details Update</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>891d4667-800b-4d21-be00-d35915b83890</testSuiteGuid>
   <testCaseLink>
      <guid>348e3448-d3d7-4b46-aafd-77773c201b48</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_OrangeHRM_002/TC002_Details Update</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>f78546b4-5809-4bcd-831f-fbd3585c341a</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/DDT_Internal Data Mode/002_Details_Internal Data Mode</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>f78546b4-5809-4bcd-831f-fbd3585c341a</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>firstName</value>
         <variableId>7a49e458-ad08-41b9-9132-d1b46b275426</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>f78546b4-5809-4bcd-831f-fbd3585c341a</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>lastName</value>
         <variableId>f82984c5-cbd0-4462-a967-058f44e6934e</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
