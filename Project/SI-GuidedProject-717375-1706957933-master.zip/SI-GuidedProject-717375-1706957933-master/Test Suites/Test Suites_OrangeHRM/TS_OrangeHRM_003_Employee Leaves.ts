<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TS_OrangeHRM_003_Employee Leaves</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>6a1e955a-718a-427e-8285-68b491465568</testSuiteGuid>
   <testCaseLink>
      <guid>1a953644-6efe-4720-96f2-e4ab6e379e1d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_OrangeHRM_003/TC003_Employee Leaves</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>799e65f9-66df-4ca2-9d0c-7d285ace0618</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/DDT_Excel Mode/001_Login_Excel</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>799e65f9-66df-4ca2-9d0c-7d285ace0618</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>username</value>
         <variableId>8c272719-8507-4224-9f8e-88cf855eeba2</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>799e65f9-66df-4ca2-9d0c-7d285ace0618</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>password</value>
         <variableId>ad06cbdf-c436-4a99-9533-5d9d4fcef743</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
